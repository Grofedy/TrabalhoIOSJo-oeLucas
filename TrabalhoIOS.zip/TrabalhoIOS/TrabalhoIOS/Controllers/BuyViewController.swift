
import UIKit

class BuyViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
